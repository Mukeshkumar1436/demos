USE Training_23Jan19_Pune

CREATE TABLE Employee_172435
(
	Employee_code		INT			NOT NULL,
	Employee_name		VARCHAR(40)	NOT NULL,
	Employee_DOB		DATE		NOT NULL,
	Employee_EmailID	VARCHAR(20)	NULL,
)
EXEC sp_help Employee_172435

ALTER TABLE Emp_172435
ADD DOB DATE

EXEC sp_help Employee_172435
ALTER TABLE Employee_172435
ALTER COLUMN Employee_EmailID VARCHAR (40)

EXEC sp_help Employee_172435
ALTER TABLE Employee_172435
DROP COLUMN Employee_DOB