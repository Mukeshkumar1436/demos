﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS_Exceptions
{
    public class EmployeeValidationException : Exception
    {
        public EmployeeValidationException(string errorMessages)
            : base(errorMessages)
        {

        }
    }
}
