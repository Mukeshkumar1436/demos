﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributesDemo
{
    [DeveloperInfo(ProjectName = "EMS", empID = 23001, DeveloperName = "Niranjan")]

    [DeveloperInfo(ProjectName = "EMS", empID = 23222, DeveloperName = "Heena")]

    class Sample
    { 

    }
    class Program
    {
        static void Main(string[] args)
        {
            Attribute[] attrs = Attribute.GetCustomAttributes(typeof(Sample));
            foreach (DeveloperInfoAttribute da in attrs)
            {
                Console.WriteLine($"empID: {da.empID}, Dev-Name: {da.DeveloperName}, pro-Name: {da.ProjectName}");
            }
            Console.ReadKey();
        }
    }
}
