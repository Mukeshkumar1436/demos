﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_DAL;
using EMS_Exceptions;

namespace EMS_BAL
{
    public class EmployeeBAL
    {
        public bool IsValid(Employee employee)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();

            if (employee.EmpId >= 101 && employee.EmpId <= 99999)  //101 - 99999
            {
                sb.Append("Employee should be in range 101 - 99999");
                valid = false;
            }
            if (!Regex.IsMatch(employee))
            {
                sb.Append
            }

            if (employee.DOJ < DateTime.Now)
            {

            }


            if (!valid)
            {
                throw new EmployeeValidationException(sb.ToString());
            }

            return valid;

        }

        public void Add(Employee employee)
        {
            try
            {
                if (IsValid(employee))
                {
                    employeeDAL.Insert(employee);
                }
            }
            catch (EmployeeValidationException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public void Modify(Employee employee)
        {
            try
            {
                if (IsValid(employee))
                {
                    employeeDAL.Insert(employee);
                }
            }
            catch (EmployeeValidationException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public void Remove(int empId)
        {
            try
            {
                employeeDAL.Delete(employee);
                
            }
            catch (EmployeeValidationException ex1)
            {
                throw ex1;
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public 
    }
}
