CREATE TABLE HierarchyTab_115022
(
NodeId    INT IDENTITY(1, 1),
NodeDepth VARCHAR(100) NOT NULL,
NodePath  HIERARCHYID NOT NULL,
NodeDesc  VARCHAR(100)
)

GO 

-- Creating constraint on hierarchy data type.
ALTER TABLE HierarchyTab_115022 
ADD CONSTRAINT U_NodePath_115022 UNIQUE CLUSTERED (NodePath)

GO

-- Inserting data in above created table.
INSERT INTO HierarchyTab_115022(NodeDepth,NodePath,NodeDesc)
VALUES 
('1',HIERARCHYID::Parse('/'),'Node-1'),
('1.1',HIERARCHYID::Parse('/1/'),'Node-2'),
('1.1.1',HIERARCHYID::Parse('/1/1/'),'Node-3'),
('1.1.2',HIERARCHYID::Parse('/1/2/'),'Node-4'),
('1.2',HIERARCHYID::Parse('/2/'),'Node-5'),
('1.2.1',HIERARCHYID::Parse('/2/1/'),'Node-6'),
('1.2.2',HIERARCHYID::Parse('/2/2/'),'Node-7'),
('1.2.2.1',HIERARCHYID::Parse('/2/2/1/'),'Node-8'),
('1.2.2.1.1',HIERARCHYID::Parse('/2/2/1/1/'),'Node-9'),
('1.2.2.1.2',HIERARCHYID::Parse('/2/2/1/2/'),'Node-10'),
('1.3',HIERARCHYID::Parse('/3/'),'Node-11'),
('1.3.1',HIERARCHYID::Parse('/3/1/'),'Node-12'),
('1.3.2',HIERARCHYID::Parse('/3/2/'),'Node-13'),
('1.4',HIERARCHYID::Parse('/4/'),'Node-14')

GO

SELECT * FROM HierarchyTab_115022

SELECT NodeId, NodeDepth, NodePath, NodePath.ToString(), NodeDesc
FROM HierarchyTab_115022

SELECT	 NodePath.ToString(),
		 HIERARCHYID::GetRoot().ToString(), 
		 NodePath.GetAncestor(1).ToString()
FROM HierarchyTab_115022