USE Training_23Jan19_Pune

SELECT * FROM Student_master

SELECT Stud_Code, Stud_Name, Address
FROM Student_master
WHERE Address IS NULL

SELECT Stud_Code, Stud_Name, Address
FROM Student_master
WHERE Address IS NOT NULL