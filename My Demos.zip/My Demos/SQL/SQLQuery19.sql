USE Training_23Jan19_Pune

SELECT COUNT(Stud_Code) StudentCount
FROM Student_master

SELECT Dept_Code, COUNT(Stud_Code) StudentCount
FROM Student_master
Group by Dept_Code

SELECT * FROM STUDENT_master

--Department wise Staff count
--Department wise staff count, total salary, average salary
--Department and designation wise staff count, total salary, average salary

SELECT * FROM Staff_Master

SELECT  Dept_Code, COUNT(Staff_Code)
FROM Staff_Master
GROUP BY Dept_Code

SELECT  Dept_Code, COUNT(Staff_code), sum(salary), avg(salary)
FROM Staff_Master
GROUP BY Dept_Code

SELECT  Dept_Code, Des_Code, COUNT(Staff_code), sum(salary), avg(salary)
FROM Staff_Master
GROUP BY Dept_Code, Des_Code

--Find the number of students as per the address

SELECT * FROM STUDENT_master

SELECT Address, COUNT(Stud_Code)
FROM Student_master
GROUP BY Address

--Display the number of student as per city, where the city has more than 1 student

SELECT Address, COUNT(Stud_Code)
FROM Student_master
GROUP BY Address
HAVING COUNT(Stud_Code) > 1