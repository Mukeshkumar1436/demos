USE Training_23Jan19_Pune

--1
select * from department_master
select * from staff_master
select staff_name,s.dept_code,dept_name,salary  from staff_master s
 inner join Department_master d on s.dept_code=d.dept_code
 where salary>20000

 ----2
 select staff_name,s.dept_code,dept_name  from staff_master s
 inner join Department_master d on s.dept_code=d.dept_code
 where s.dept_code <> 10

 ---3
 select * from book_master
 select * from book_transaction

 select book_name,count(*) as no_of_days from book_master 
 where book_name in('let us c','mastering vc++') 
 group by book_name

 -----5
 select * from Staff_master

 select a.staff_code,a.staff_name,b.mgr_code 
 from staff_master a,staff_master b 
 where a.mgr_code=b.mgr_code order by staff_code

 --6

 select * from Staff_master
 select * from Department_master

 select Staff_code,Staff_name,dept_name,hiredate,
 datename(WEEKDAY,hiredate) as Day from staff_master s 
 inner join Department_master d 
 on s.dept_code=d.dept_code 

  -- 8
 select * from Staff_Master

 select staff_code,staff_name,dept_code,Hiredate,
 datediff(yyyy,hiredate,getdate()) as numberofyears from staff_master
 
 ----9
select * from Staff_Master where hiredate < '2000-01-01'





---8

select * from student_marks
select stud_code,subject1 from student_marks 
where subject1=(select max(subject1) from student_marks)

---9
select b.stud_code,subject1,stud_name from student_marks a
 inner join student_master b on a.stud_code=b.stud_code
where subject1=(select max(subject1) from student_marks)

--10
select * from book_master
select * from Book_Transaction

select book_code,author,book_category from book_master
where not exists(select * from book_transaction
where book_master.book_code=book_transaction.book_code)

--11

select * from staff_master
select * from student_master
 select staff_code,staff_name,stud_code,stud_name,b.dept_code 
 from staff_master a inner join student_master b
 on a.dept_code=b.dept_code 
 where b.dept_code=20
 
--12 
 select * from student_master
 select * from student_marks

 select b.stud_code,stud_name,a.Stud_Year from student_master a
 inner join student_marks b on a.stud_code=b.stud_code
 where a.Stud_Year= 2018

--13
 select * from student_master
 select * from book_transaction

 select a.stud_code,a.stud_name,b.book_code 
 from student_master a right outer join Book_Transaction b
 on a.Stud_Code=b.stud_code

 ----14

select * from mukhem_172435.customer_440
truncate table mukhem_172435.customer_440

insert into mukhem_172435.customer_440
values('ALFKI','AlfredsFutterKiste','ObereStr.57','Berlin Germany',
030-0074321,12209,NULL,NULL)

insert into mukhem_172435.customer_440 values
('ANATR','Ana Trujillo',
'Avda.dela constitucion 2222','Mexico DF.Mexico',5554729,5021,
'NA',NULL)

insert into mukhem_172435.customer_440 values('ANTON',
'Antonio','matadero 2312','Mexico DF.MEXICO'
,5553932,5023,NULL,NULL)

insert into mukhem_172435.customer_440 values('AROUT',
'around the Horn','120 Hanover sq.','London UK',
5557788,'WA1 iDP',NULL,NULL)

insert into mukhem_172435.customer_440 values('BERGS',
'Berglundssnabbkop','Berguvsvagen 8','Lulea Sweden'
,0921123465,'S958 22',NULL,NULL)

insert into mukhem_172435.customer_440 values('BLAUS',
'Blauer see Delik','Forster 57','Mannheim Germany',062108460,
68306,'NA',NULL)

insert into mukhem_172435.customer_440 values('BLONP',
'Blondesddslpreet','24,place kleber','Strausbourg France'
,88.601531,67000,NULL,NULL)

insert into mukhem_172435.customer_440 values('BOLID',
'Bolindo paradas','c/ araquil 67','Madrid Spain',5552282,
28023,'EU',NULL)

insert into mukhem_172435.customer_440 values('BONAP','Bon app'
,'12,rueders bouchers','Marseille France',91.244540,13008,NULL,NULL)

insert into mukhem_172435.customer_440 values('BOTTM',
'Bottom Dollar','23 Tsawessen Blvd','Tsawessen canada',
5554729,'T2F8M4','BC',' ')


--15
update mukhem_172435.customer_440 set 
contactNumber=replace(contactnumber,5554729,3332345)
where customerid='ANATR'

--16
update mukhem_172435.customer_440 set 
address1=replace(address1,'23 Tsawessen Blvd','19/2 12th blockSpring fields')
update mukhem_172435.customer_440 set
address2=replace(address2,'Tsawessen canada','Ireland-UK')
where customerid='BOTTM'
update mukhem_172435.customer_440 set
region=replace(region,'BC','EU')
where customerid='BOTTM'

--17

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('AROUT','4-jul-96','P')

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('ALFKI','4-jul-96','C')

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('BLONP','8-jul-96','P')

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('ANTON','8-jul-96','P')

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('ANTON','9-jul-96','P')

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('BOTTM','10-jul-96','P')


insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('BONAP','11-jul-96','C')

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('ANATR','12-jul-96','P')

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('BLAUSS','15-jul-96','P')

insert into mukhem_172435.orders_440(customerid,ordersdate,orderstate)
values ('HILAA','16-jul-96','C')


---18
 delete from mukhem_172435.orders where ordersstate='C'
select* from mukhem_172435.orders



---19

truncate table mukhem_172435.orders

---20
update mukhem_172435.orders set ordersstate='C' where ordersdate<'1996-07-15'