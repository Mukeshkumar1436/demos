USE Training_23Jan19_Pune

SELECT Degree='BE', RollNo=Stud_Code
FROM Student_master

SELECT Stud_Code, Subject1, Subject2, Subject3, 
		Total = (Subject1+Subject2+Subject3)
FROM Student_Marks

SELECT Stud_Code, Subject1, Subject2, Subject3, 
		Total = (Subject1+Subject2+Subject3),
		Average = (Subject1+Subject2+Subject3)/3
FROM Student_Marks