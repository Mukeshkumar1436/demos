USE Training_23Jan19_Pune

--Computed Columns
CREATE TABLE Marks_172435
(
	Test1		INT,
	Test2		INT,
	Total		AS (Test1 + Test2),
	TestAvg		AS (Test1 + Test2)/2,
) 

The column "Total" and "TestAvg" cannot be modified because it is either a computed column or is the result of a UNION operator.
INSERT INTO Marks_172435 (Test1, Test2, Total, TestAvg)
VALUES(20, 30, 40, 50)

INSERT INTO Marks_172435
VALUES(30, 40)

INSERT INTO Marks_172435(Test1, Test2)
VALUES(50,60)

SELECT * FROM Marks_172435
EXEC sp_help Marks_172435

CREATE TABLE Printer_172435
(
	PrinterID		INT IDENTITY(1000,3),
	PrinterName		VARCHAR(40)
)


INSERT INTO Printer_172435(PrinterID, PrinterName)
VALUES(101, 'HP Laser')

INSERT INTO Printer_172435(PrinterName)
VALUES('HP Laser')
SELECT * FROM PRINTER_172435


INSERT INTO Printer_172435(PrinterName)
VALUES('CANON')

EXEC sp_help Printer_172435

--UniqueIdentifier Column
CREATE TABLE Hardware_172435
(
	Hardware		UNIQUEIDENTIFIER,
	HardwareName	VARCHAR(20)
)

INSERT INTO Hardware_172435(Hardware, HardwareName)
VALUES(NEWID(), 'Printer')

SELECT * FROM Hardware_172435





