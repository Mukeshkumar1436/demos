use Training_23Jan19_Pune

--write a stored procedure to display all staff of specific designation
create proc usp_staffdes_172435
(
	@des_code	int
) 
as
begin
	if(@des_code is null or @des_code <=0)
	begin
		raiserror('designation code cannot be null or less than 0', 1, 1)
		return-1
	end
	else
	begin
		if not exists (select design_code
						from desig_master 
						where design_code = @des_code)
		begin 
			raiserror('designation code does not exists', 1, 1)
		end
		select staff_code, staff_name, des_code
		from staff_master
		where des_code = @des_code
	end
end

exec usp_staffdes_172435 null

exec usp_staffdes_172435 -1

exec usp_staffdes_172435 102