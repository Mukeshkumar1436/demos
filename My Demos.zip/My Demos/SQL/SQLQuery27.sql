USE Training_23Jan19_Pune

declare @dcode			int
declare @dname			varchar(20)
declare @errornumber	int

set @dcode = 10
set @dname = 'Maintainance'

insert into department_master(dept_code, dept_name)
values (@dcode, @dname)

set @errornumber = @@error
if @errornumber > 0
begin 
	print 'error occured'
	print @errornumber
end
else
begin
	print 'record added successfully'
end