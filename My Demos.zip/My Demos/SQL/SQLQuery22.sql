USE Training_23Jan19_Pune

SELECT * FROM Student_master
SELECT * FROM Book_Transaction
SELECT * FROM Book_Master

--CROSS JOIN
SELECT bt.Book_code, bt.Stud_Code, sm.Stud_Name, bt.Issue_Date
FROM Book_Transaction bt, Student_master sm

SELECT bt.Book_code, bt.Stud_Code, sm.Stud_Name, bt.Issue_Date
FROM Book_Transaction bt CROSS JOIN Student_master sm

--INNER JOIN
SELECT bt.Book_code, bt.Stud_Code, sm.Stud_Name, bt.Issue_Date
FROM Book_Transaction bt, Student_master sm
WHERE bt.Stud_Code = sm.Stud_Code


SELECT bt.Book_code, bt.Stud_Code, sm.Stud_Name, bt.Issue_Date
FROM Book_Transaction bt INNER JOIN Student_master sm
ON bt.Stud_Code = sm.Stud_Code

--Display the student name with book name which is issued by student
SELECT bt.Book_code, bm.Book_Name, sm.Stud_Code, sm.Stud_Name
FROM Book_Transaction bt
INNER JOIN Book_Master bm
ON bt.Book_code = bm.Book_code
INNER JOIN Student_Master sm
ON bt.Stud_code = sm.Stud_code


--OUTER JOIN
--Left Outer Join
--Display book transaction details for all students whether they issued the book or not

SELECT sm.Stud_Code, sm.Stud_Name,bt.Book_Code
FROM Student_master sm LEFT OUTER JOIN Book_Transaction bt
ON SM.Stud_code = bt.Stud_code

--Display book transaction details for all books whether it is issued or not
SELECT sm.Stud_Code, sm.Stud_Name,bt.Book_Code
FROM Student_master sm RIGHT OUTER JOIN Book_Transaction bt
ON SM.Stud_code = bt.Stud_code

--Display book transaction details for all Students whether it is issued or not
SELECT sm.Stud_Code, sm.Stud_Name,bt.Book_Code
FROM Student_master sm FULL OUTER JOIN Book_Transaction bt
ON SM.Stud_code = bt.Stud_code

--SELF JOIN
--Display staff name with manager name
SELECT emp.Staff_code, emp.staff_name, mgr.staff_name 
FROM Staff_Master emp
INNER JOIN Staff_master mgr
ON EMP.mGR_CODE = MGR.sTAFF_Code


--Display student marks with student name
--Display name of books which are issued by staff
--Display name of books and staff name which are issued by staff
--Display department name for student
--Display department name and designation name of staff
--Display all books whether they are issued by staff or not
--Display book transaction details and all staff details , whether the staff has issued the book or not

SELECT s.stud_name, s.stud_code, m.subject1, m.subject2, m.subject3
FROM Student_master s INNER JOIN student_marks m
ON s.Stud_code = m.Stud_Code


SELECT bt.Book_code, bm.Book_Name, bt.Stud_Code
FROM Book_Transaction bt
INNER JOIN Book_Master bm
ON bt.Book_code = bm.Book_code
INNER JOIN Staff_master sm
ON bt.Staff_code = sm.Staff_code


SELECT sm.Stud_Code, sm.Stud_Name, dm.Dept_Code
FROM Student_master sm LEFT OUTER JOIN Book_Transaction bt
ON SM.Dept_code = dm.Dept_code

SELECT sm.staff_code, sm.staff_name, dept_name, des.design_name
from staff_master sm inner join department_master dept
on sm.dept_code = dept.dept_code
inner join desig_master des
on sm.des_code = des.design_code

select bt.book_code, sm.staff_code, sm.staff_name
from book_transaction bt left outer join staff_master sm
on bt.staff_code = sm.staff_code


