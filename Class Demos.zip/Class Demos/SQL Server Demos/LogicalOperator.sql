USE Training_23Jan19_Pune

SELECT * FROM Staff_Master

SELECT Staff_Code, Staff_Name, Des_Code, Dept_Code
From Staff_Master
WHERE Des_Code = 102 AND Dept_Code = 20

SELECT Staff_Code, Staff_Name, Des_Code, Dept_Code
From Staff_Master
WHERE Des_Code = 102 OR Dept_Code = 20

SELECT Stud_Code, Subject1
FROM Student_Marks
WHERE Subject1 >= 70 AND Subject1 <= 90

SELECT Stud_Code, Subject1
FROM Student_Marks
WHERE Subject1 BETWEEN 70 AND 90

SELECT * FROM Student_master

SELECT Stud_Code, Stud_Name, Dept_Code
FROM Student_master
WHERE Dept_Code = 10 OR Dept_Code = 30 OR Dept_Code = 50

SELECT Stud_Code, Stud_Name, Dept_Code
FROM Student_master
WHERE Dept_Code IN (10, 30, 50)

--Display all students whose name contains 3 characters
SELECT Stud_Code, Stud_Name
FROM Student_master
WHERE Stud_Name LIKE '___'

--Display all students whose name starts with A
SELECT Stud_Code, Stud_Name
FROM Student_master
WHERE Stud_Name LIKE 'A%'

--Display all students whose name ends with hul and name has 5 characters
SELECT Stud_Code, Stud_Name
FROM Student_master
WHERE Stud_Name LIKE '__hul'

--Display all students whose name ends with l
SELECT Stud_Code, Stud_Name
FROM Student_master
WHERE Stud_Name LIKE '%l'

--Display all students whose name contains h
SELECT Stud_Code, Stud_Name
FROM Student_master
WHERE Stud_Name LIKE '%h%'

--Display all students whose name does not contain m
SELECT Stud_Code, Stud_Name
FROM Student_master
WHERE Stud_Name NOT LIKE '%m%'