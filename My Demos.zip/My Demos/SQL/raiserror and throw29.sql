--raiserror
begin try
	declare @result	int
	set @result = 1/0
end try
begin catch
	declare @errormessage varchar(200)
	declare @severity		int

	set @errormessage  = error_message()
	set @severity	    = error_severity()

	raiserror(@errormessage, @severity, 1)
end catch



--throw keyword
begin try
	declare @result	int
	set @result = 1/0
end try
begin catch
	throw
end catch

select * from sysmessages