USE Training_23Jan19_Pune

SELECT * FROM Employee_172435
CREATE CLUSTERED INDEX CL_employee_code
ON Employee_172435(Employee_code) 
exec sp_help Employee_172435

CREATE NONCLUSTERED INDEX NCL_employee_EmailID
ON Employee_172435(Employee_EmailID)
exec sp_help Employee_172435

