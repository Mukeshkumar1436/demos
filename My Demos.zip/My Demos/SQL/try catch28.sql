USE Training_23Jan19_Pune

declare @dcode			int
declare @dname			varchar(20)
declare @errornumber	int

set @dcode = 10
set @dname = 'Maintainance'

begin try
insert into department_master(dept_code, dept_name)
values (@dcode, @dname)
end try

begin catch
	print 'error occured'
	print error_number()
	print error_message()
	print error_severity()
end catch
