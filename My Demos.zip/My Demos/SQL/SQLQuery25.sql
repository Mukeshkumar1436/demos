USE Training_23Jan19_Pune

exec sp_help emp_172435

exec sp_helpindex emp_172435


--create a view for storing data stud_code, stud_name and dept_code
create view studentview_172435
as
select stud_code,stud_name, dept_code
from student_master


select * from studentview_172435

select * from syscomments where text like '%172435%'

--create view to store staff_code. staff_name, des_name, dept_name for all staff
select * from staff_master
create view staffview_172435
as
select staff_code, staff_name, des_code, dept_code
from staff_master 

select * from staffview_172435


select * from syscomments where text like '%172435%'

--create view to show department wise student count
select * from student_master
create view studcountview_172435
with encryption
as
select dept_code, count(stud_code) as stud_count
from student_master
group by dept_code
--hide the definition of view


select * from studcountview_172435

select * from syscomments where text like '%172435%'
