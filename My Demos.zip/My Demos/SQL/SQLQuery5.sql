USE Training_23Jan19_Pune
Create Type EmailAddress_172435
From Varchar(50) NOT NULL

CREATE TABLE Emp_172435
(
EmpID		INT,
EmpName		VARCHAR(20),
DOJ			DATE,
Email		EmailAddress_172435,
Phone		CHAR(10)
)

EXEC sp_help Emp_172435
SELECT * FROM Emp_172435

DROP TYPE EmailAddress_172435