USE Training_23Jan19_Pune

SELECT * FROM Emp_115022
SELECT * FROM Employee_115022

UPDATE Employee_115022
SET Employee_DOB = '1995-12-12'
WHERE Employee_Code = 1001

UPDATE Employee_115022
SET Employee_DOB = '1993-06-06'
WHERE Employee_Code = 1006

MERGE INTO Emp_115022 AS TGT
USING Employee_115022 AS SRC
ON TGT.EmpID = SRC.Employee_Code
WHEN MATCHED THEN
	UPDATE SET TGT.DOB = SRC.Employee_DOB
WHEN NOT MATCHED THEN
	INSERT (EmpID, EmpName, Email, DOB)
	VALUES (SRC.Employee_Code, SRC.Employee_Name, SRC.Employee_EmailID, SRC.Employee_DOB)
OUTPUT $action, inserted.EmpID AS ins_empid;

exec sp_help Emp_115022
exec sp_help Employee_115022