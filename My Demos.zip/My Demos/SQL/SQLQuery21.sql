USE Training_23Jan19_Pune

--Column name is problem
SELECT Dept_Code, COUNT(Staff_Code) 
FROM Staff_Master
GROUP BY Dept_Code
UNION
SELECT Des_Code, COUNT(Staff_Code) 
FROM Staff_Master
GROUP BY Des_Code


--Problem is datatype of the column
SELECT Dept_Code, COUNT(Staff_Code)
FROM Staff_master
group by dept_code
UNION
SELECT Address, COUNT(Staff_Code)
FROM Staff_master
group by Address

--Solved
SELECT Dept_Code, Desc_code = NULL, COUNT(Staff_Code)
FROM Staff_master
group by dept_code
UNION
SELECT Dept_Code = NULL, Des_Code, COUNT(Staff_Code)
FROM Staff_master
group by Des_Code

SELECT Dept_Code, Address = NULL, COUNT(Staff_Code)
FROM Staff_master
group by dept_code
UNION
SELECT Dept_Code = NULL, Address, COUNT(Staff_Code)
FROM Staff_master
group by Address



--GROUPING SETS
SELECT Dept_Code, Des_Code, COUNT (Staff_Code)
FROM Staff_Master
GROUP BY GROUPING SETS ((Dept_Code), (Des_Code))


SELECT Dept_Code, Address, COUNT (Stud_Code)
FROM Student_Master
GROUP BY GROUPING SETS ((Dept_Code), (Address))






