SELECT * FROM sys.tables
SELECT * FROM sys.sysusers