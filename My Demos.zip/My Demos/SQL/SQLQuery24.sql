USE Training_23Jan19_Pune

--Display all students whose department is same as stud_1012

select dept_code 
from student_master
where stud_code = 1012

--o/p is 30

select stud_code, stud_name, dept_code
from student_master
where dept_code = 30 


select stud_code, stud_name, dept_code
from student_master
where dept_code = (select dept_code
					from student_master
					where stud_code = 1012) 

--Display all staff, whose salary is greater than all staff of dept_20
select staff_code, staff_name, salary
from staff_master
where salary >ALL (select salary
				from staff_master
				where dept_code = 20)

select staff_code, staff_name, salary
from staff_master
where salary >ANY (select salary
				from staff_master
				where dept_code = 20)







