﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_BAL;
using EMS_Entities;
using EMS_Exceptions;


namespace EmployeeManagementSystem
{
    public class Manager
    {
        static void Main(string[] args)
        {
            try
            {
                Employee employee = new Employee
                {
                    EmpId = 1,
                    DOJ = DateTime.Now.AddDays(2),
                    Salary = 12000,
                    EmpName = @"sf$ *%@12sdfs sdf"
                };

                employeeBAL.Add(employee);
                Console.WriteLine("Inserted");

                List<Employee> employees = EmployeeBAL.GetAll();
                foreach (var item in employees)
                {
                    Console.WriteLine(item); //EMS_Entities.Employee
                }

            }

            catch (EmployeeValidationException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (EmployeeNotFoundException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch ( ex1)
            {
                Console.WriteLine(ex1.Message);
            }


        }
    }
}
