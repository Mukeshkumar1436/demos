use Training_23Jan19_Pune

--write a procedure to access the students based on city
create proc usp_retrievestudbycity_172435
(
	@city	varchar(30)
)
as 
begin
	if (@city is null or @city = '')
	begin
		print 'city should be provided'
	end
	else
	begin
		select stud_code, stud_name, address
		from student_master
		where address = @city
	end
end

select * from syscomments where text like'%172435'

exec usp_retrievestudbycity_172435 @city = 'chennai'


exec usp_retrievestudbycity_172435 'bangalore'


--write a store procedure to dispaly the count of students from particular department
select * from student_master
create proc usp_studcountdept_172435
(
	@dcode	int,
	@scount	int		out
)
as 
begin
	if (@dcode is null or @dcode < 0)
	begin
		print 'department code should be provided and it cannot be'
	end
	else
	begin
		if exists (select dept_code	
			from department_master
			where dept_code = @dcode)
		begin
			select @scount = count(stud_code)
			from student_master
			where dept_code = @dcode
		end
	end
end
declare @count	int
exec usp_studcountdept_172435 0,@count out
select @count



--executing stored procedure with result sets

exec usp_retrievestudbycity_172435 @city = 'chennai' 
with result sets((scode int, sname varchar(20), city varchar(20)))



--To view the definition of stored procedure

select * from syscomments where text like '172435'

select * from sysobjects

select object_definition(object_id('usp_retrievestudbycity_172435'))

exec sp_helptext usp_retrievestudbycity_172435
