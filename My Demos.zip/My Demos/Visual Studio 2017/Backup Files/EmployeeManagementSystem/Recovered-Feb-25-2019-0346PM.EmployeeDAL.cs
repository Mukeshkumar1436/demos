﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_Entities;
using EMS_Exceptions;

namespace EMS_DAL
{
    //DAL for CRUD operations
    public class EmployeeDAL
    {
        List<Employee> employees = new List<Employee>();

        //Inserting employee into collection
        public void Insert(Employee employee)
        {
            try
            {
                employees.Add(employee);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public void Update(Employee employee)
        {
            employees.Add(employee);
        }

        public void Delete(Employee employee)
        {
            try
            {
                for (int i = 0; i < employees.Count; i++)
                {
                    if (employee[i].EmpId = employee.EmpId) ;
                    {
                        //employee.remove(employee[i]);
                        employees.RemoveAt(i);
                        isDeleted = true;
                        break;

                    }
                }
                if (!isDeleted)
                {
                    throw new EmployeeNotFoundException("Employee not found");
                }

            }
            catch
            {

            }
            employees.Add(employee);
        }

        public List<Employee> SelectAll()
        {
            return employees;
        }
    }
}
