--Write a stored procedure to display all staff of specific designation
CREATE PROC usp_StaffDes_115022
(
	@des_code	INT
)
AS
BEGIN
	IF(@des_code IS NULL OR @des_code <= 0)
	BEGIN
		RAISERROR('Designation code cannot be NULL or less than 0', 1, 1)
		RETURN -1
	END
	ELSE
	BEGIN
		IF NOT EXISTS (SELECT Design_Code 
					FROM Desig_master 
					WHERE Design_Code=@des_code)
		BEGIN
			RAISERROR('Designation code does not exists', 1, 1)
			RETURN -1
		END

		SELECT Staff_Code, Staff_Name, Des_code
		FROM Staff_Master
		WHERE Des_code = @des_code
	END
END

EXEC usp_StaffDes_115022 NULL

EXEC usp_StaffDes_115022 -1

EXEC usp_StaffDes_115022 10

EXEC usp_StaffDes_115022 101

EXEC usp_StaffDes_115022 102