USE Training_23Jan19_Pune

--Display all students whose department is same as stud 1012
SELECT Dept_Code
FROM Student_master
WHERE Stud_Code = 1012
--o/p is 30

SELECT Stud_Code, Stud_Name, Dept_Code
FROM Student_master
WHERE Dept_Code = 30


SELECT Stud_Code, Stud_Name, Dept_Code
FROM Student_master
WHERE Dept_Code = (SELECT Dept_Code
					FROM Student_master
					WHERE Stud_Code = 1012)

--Display all staff, whose salary is greater than all staff of dept 20

SELECT Staff_Code, Staff_Name, Salary
FROM Staff_Master
WHERE Salary >ALL (SELECT Salary
				FROM Staff_Master
				WHERE Dept_Code = 20)

--Display all staff, whose salary is greater than any staff of dept 20
SELECT Staff_Code, Staff_Name, Salary
FROM Staff_Master
WHERE Salary > ANY (SELECT Salary
				FROM Staff_Master
				WHERE Dept_Code = 20)