﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileReadingWriting_Demo
{
    class Program
    {
        static void WriteContent(List<string> lines, string filePath)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;
            try
            {
                fileStream = new FileStream(filePath, FileMode.Append);
                streamWriter = new StreamWriter(fileStream);
                foreach (var In in lines)
                {
                    streamWriter.WriteLine(In);
                }

               
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                streamWriter.Close();
                fileStream.Close();
            }
        }



        static List<string> ReadContent(string filePath)
        {
            try
            {
           
           
            FileStream fileStream = new FileStream(filePath, FileMode.Open);
            StreamReader streamReader = new StreamReader(fileStream);
            List<string> lines = new List<string>();
            {
                streamReader.ReadLine(In);
            }

            streamReader.Close();
            fileStream.Close();
        }

        static void Main(string[] args)
        {
            string path = @"C:\temp\MyFolder\Abc.txt";
            List<string> lines = new List<string>
            {
                "This is my first line",
                "This is my second line",
                "And this is ladt line"
            };
            WriteContent(lines, path);

            List<string> c_lines = ReadContent(string filePath);
            foreach (var item in c_lines)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();


        }
    }
}
