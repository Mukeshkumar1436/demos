use Training_23Jan19_Pune

GO
CREATE SCHEMA MMK
GO

CREATE TABLE MMK.Prod
(
	ProdID	INT,
	Name	VARCHAR(20),
	Quantity INT
)

SELECT * FROM MMK.Prod
